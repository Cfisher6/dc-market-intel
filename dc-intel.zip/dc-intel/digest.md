# Staging digest — 2026-07-26

Machine-collected and rule-typed. **Nothing here is verified.** Run this through
a judgment pass before promoting anything into `data/market-data.js`.

What the rules cannot do, and you must:

- Tell a genuinely new campus from the same one re-announced for the third time
- Resolve "a leading AI company" to an actual counterparty
- Decide whether a quoted MW is IT load or gross when the article does not say
- Read whether a guarantee sits at parent or opco
- Judge whether an announced project is financeable or a press release

Sources checked: Data Center Dynamics FAILED, Data Center Frontier FAILED, Data Center Planet FAILED, Utility Dive FAILED

---

> **Feed problems:** Data Center Dynamics — offline; Data Center Frontier — offline; Data Center Planet — offline; Utility Dive — offline


## Ranked events (0 of 0 above threshold, 14-day window)



## Manual sources — check these by hand

- **DC Byte** — Subscription market intelligence. The compiled dataset is the product.
- **Baxtel** — Compiled facility database. Bulk extraction is against terms; check for an API.
- **CBRE / JLL / Cushman** — Free summary reports may be cited; subscription products may not.
