/* Renders every panel from window.DC_DATA. No framework, no build step. */
(function () {
  "use strict";

  var D = window.DC_DATA;
  if (!D) { document.body.innerHTML = "<p style='padding:40px'>market-data.js failed to load.</p>"; return; }

  var esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  };
  var el = function (id) { return document.getElementById(id); };
  var fmt = function (n) { return n == null ? "—" : n.toLocaleString("en-US"); };

  function srcLink(name, url) {
    if (!url) return "";
    return '<a class="src" href="' + esc(url) + '" target="_blank" rel="noopener">' + esc(name) + "</a>";
  }
  function methodPill(m) {
    if (!m) return "";
    return '<span class="pill ' + esc(m.toLowerCase()) + '">' + esc(m) + "</span>";
  }

  /* --- hero ------------------------------------------------------------- */
  function renderHero() {
    var c = D.constraint;
    var ratio = Math.round((c.queue_gw * 1000) / c.approved_mw_12mo);
    el("ratio").innerHTML = ratio.toLocaleString("en-US") + "<em>:1</em>";
    el("ratio-caption").innerHTML =
      "For every megawatt ERCOT actually approved to energize over the trailing twelve months, roughly " +
      "<strong>" + ratio.toLocaleString("en-US") + " MW</strong> sits in the large-load queue — " +
      Math.round(c.queue_dc_share * 100) + "% of it data centers. " +
      "Demand is not the constraint in this market. Interconnection is.";

    var queueMW = c.queue_gw * 1000;
    el("scale").innerHTML =
      scaleRow("Large-load queue", queueMW.toLocaleString("en-US") + " MW", 100, false,
               "~" + Math.round(c.queue_dc_share * 100) + "% data centers · " + c.as_of) +
      scaleRow("Approved to energize, trailing 12 months", c.approved_mw_12mo.toLocaleString("en-US") + " MW",
               Math.max((c.approved_mw_12mo / queueMW) * 100, 0.35), true,
               "The number that actually clears") +
      '<div style="margin-top:22px">' +
        srcLink("ERCOT Large Load Update, April 2026", c.url) +
        srcLink("ERCOT Large Load Working Group, March 2026", c.approvals_url) +
      "</div>";
  }
  function scaleRow(label, value, pct, constrained, note) {
    return '<div class="scale-row">' +
      '<div class="scale-label"><span>' + esc(label) + "</span><b>" + esc(value) + "</b></div>" +
      '<div class="scale-track"><div class="scale-fill' + (constrained ? " constrained" : "") +
        '" style="width:' + pct + '%"></div></div>' +
      '<div class="scale-note">' + esc(note) + "</div></div>";
  }

  /* --- generic metric grid --------------------------------------------- */
  function metricGrid(items) {
    return '<div class="metrics">' + items.map(function (m) {
      return '<div class="metric">' +
        '<div class="metric-label">' + esc(m.label) + methodPill(m.method) + "</div>" +
        '<div class="metric-value">' + esc(m.value) + "</div>" +
        (m.note ? '<div class="metric-note">' + esc(m.note) + "</div>" : "") +
        '<div class="metric-note" style="color:var(--slate-lt)">' + esc(m.as_of || "") + "</div>" +
        srcLink(m.source, m.url) +
      "</div>";
    }).join("") + "</div>";
  }

  /* --- layer 1: fundamentals -------------------------------------------- */
  function renderFundamentals() {
    var f = D.fundamentals, h = "";

    h += '<h2 class="sec">Headline fundamentals</h2>' + metricGrid(f.headline);

    // absorption
    var a = f.absorption;
    var max = 2600;
    h += '<h2 class="sec">Net absorption</h2><table><caption>' + esc(a.caption) + "</caption>" +
      "<thead><tr><th>Market</th><th class='num'>FY 2025 (MW)</th><th class='num'>Q1 2026 (MW)</th><th>Note</th></tr></thead><tbody>";
    a.rows.forEach(function (r) {
      h += "<tr><td><strong>" + esc(r.market) + "</strong></td>" +
        "<td class='num'>" + fmt(r.fy2025) +
          (r.fy2025 ? '<span class="tbar" style="width:' + (r.fy2025 / max * 100) + '%"></span>' : "") + "</td>" +
        "<td class='num'>" + (r.q1_2026 == null ? '<span class="dash">—</span>' : fmt(r.q1_2026) +
          '<span class="tbar alt" style="width:' + (r.q1_2026 / max * 100) + '%"></span>') + "</td>" +
        "<td>" + esc(r.note || "") + "</td></tr>";
    });
    h += "</tbody></table>" + srcLink(a.source, a.url);

    // vacancy
    var v = f.vacancy_detail, vmax = 20;
    h += '<h2 class="sec">Vacancy by market</h2><table><caption>' + esc(v.caption) + "</caption>" +
      "<thead><tr><th>Market</th><th class='num'>Vacancy</th><th style='width:45%'></th></tr></thead><tbody>";
    v.rows.forEach(function (r) {
      h += "<tr><td>" + esc(r.market) + "</td><td class='num'>" + r.vacancy.toFixed(1) + "%</td>" +
        '<td><span class="tbar' + (r.vacancy < 2 ? " alt" : "") + '" style="width:' +
        (r.vacancy / vmax * 100) + '%;margin-top:4px"></span></td></tr>';
    });
    h += "</tbody></table>" + srcLink(v.source, v.url);

    // methodology divergence
    var n = f.nova;
    h += '<h2 class="sec">Methodology divergence — why you cannot blend these</h2>' +
      "<table><caption>" + esc(n.caption) + "</caption>" +
      "<thead><tr><th>Metric</th><th>CBRE</th><th>JLL</th></tr></thead><tbody>";
    n.rows.forEach(function (r) {
      h += "<tr><td><strong>" + esc(r.metric) + "</strong></td><td>" + esc(r.cbre) + "</td><td>" + esc(r.jll) + "</td></tr>";
    });
    h += "</tbody></table>" + srcLink(n.source, n.url);

    el("panel-fundamentals").innerHTML = h;
  }

  /* --- layer 2: power ---------------------------------------------------- */
  function renderPower() {
    var p = D.power, h = "";
    h += '<h2 class="sec">Interconnection</h2>' + metricGrid(p.headline);

    var g = p.gen_queue, gmax = 180000;
    h += '<h2 class="sec">ERCOT generation queue</h2><table><caption>' + esc(g.caption) +
      " As of " + esc(g.as_of) + ".</caption>" +
      "<thead><tr><th>Technology</th><th class='num'>MW</th><th style='width:45%'></th></tr></thead><tbody>";
    g.rows.forEach(function (r) {
      h += "<tr><td>" + esc(r.tech) + "</td><td class='num'>" + fmt(r.mw) + "</td>" +
        '<td><span class="tbar" style="width:' + (r.mw / gmax * 100) + '%;margin-top:4px"></span></td></tr>';
    });
    h += "</tbody></table>" + srcLink(g.source, g.url);

    h += '<h2 class="sec">Regulatory watchlist</h2><div class="watch">';
    p.watchlist.forEach(function (w) {
      h += '<div class="watch-item"><div><h3>' + esc(w.item) + "</h3>" +
        '<div class="watch-status">' + esc(w.status) + "</div></div>" +
        '<div><p class="watch-why">' + esc(w.why) + "</p>" + srcLink(w.source, w.url) + "</div></div>";
    });
    h += "</div>";
    el("panel-power").innerHTML = h;
  }

  /* --- layer 3: capital markets ----------------------------------------- */
  function renderCapital() {
    var c = D.capital, h = "";
    h += '<h2 class="sec">What is publicly visible</h2>' + metricGrid(c.headline);
    h += '<h2 class="sec">Known gaps</h2><div class="gapbox"><h3>Not obtainable from public sources</h3><ul>' +
      c.gaps.map(function (g) { return "<li>" + esc(g) + "</li>"; }).join("") +
      "</ul><p>" + esc(c.note) + "</p></div>";
    el("panel-capital").innerHTML = h;
  }

  /* --- layer 4: counterparty -------------------------------------------- */
  function renderCounterparty() {
    var c = D.counterparty, h = "";
    var max = 210;

    h += '<h2 class="sec">2026 capex guidance</h2><table><caption>' + esc(c.caption) + "</caption>" +
      "<thead><tr><th>Counterparty</th><th class='num'>2025 actual ($B)</th><th class='num'>2026 guide ($B)</th>" +
      "<th>Revision</th></tr></thead><tbody>";
    c.rows.forEach(function (r) {
      var band = r.low === r.high ? "$" + r.low + "B" : "$" + r.low + "–" + r.high + "B";
      h += "<tr><td><strong>" + esc(r.name) + "</strong><span class='sub'>" + esc(r.note) + "</span></td>" +
        "<td class='num'>" + fmt(r.fy2025) +
          '<span class="tbar" style="width:' + (r.fy2025 / max * 100) + '%"></span></td>' +
        "<td class='num'>" + esc(band) +
          '<span class="tbar alt" style="width:' + (r.capex_2026 / max * 100) + '%"></span></td>' +
        "<td><span class='sub' style='margin-top:0'>from " + esc(r.initial) +
          (r.revised !== "—" ? "<br>→ " + esc(r.revised) : "") + "</span></td></tr>";
    });
    h += "</tbody></table>" + srcLink(c.source, c.url);

    var a = c.aggregate;
    h += '<h2 class="sec">Aggregate</h2>' + metricGrid([
      { label: "Combined 2026 guidance", value: a.total_2026, note: a.note, as_of: "Mid-2026", source: a.source, url: a.url },
      { label: "Combined 2025 actual", value: a.total_2025, note: "", as_of: "FY 2025", source: a.source, url: a.url },
      { label: "Year-over-year growth", value: a.growth, note: "", as_of: "2026", source: a.source, url: a.url }
    ]);

    h += '<h2 class="sec">Contracted backlog — the credit read</h2>' + metricGrid(c.credit.map(function (x) {
      return { label: x.label, value: x.value, note: x.note, as_of: "", source: x.source, url: x.url };
    }));

    el("panel-counterparty").innerHTML = h;
  }

  /* --- layer 5: equities -------------------------------------------------- */
  function renderEquities() {
    var e = D.equities, h = "";
    h += '<div class="gapbox" style="border-left-color:var(--slate);margin-bottom:34px">' +
      "<h3>Structural note</h3><p style='margin-top:0'>" + esc(e.note) + "</p></div>";
    h += '<h2 class="sec">Sub-sector map</h2><div class="seg">';
    e.segments.forEach(function (s) {
      h += '<div class="seg-row"><div class="seg-name">' + esc(s.segment) + "</div>" +
        '<div class="seg-tickers">' + esc(s.names) + "</div>" +
        '<div class="seg-thesis">' + esc(s.thesis) + "</div></div>";
    });
    h += "</div>";
    el("panel-equities").innerHTML = h;
  }


  /* --- feed-driven panels ------------------------------------------------ */
  var F = window.DC_FEED || null;

  function feedBar() {
    if (!F) return '<div class="feedbar warn">feed.js not present — run the collector.</div>';
    var bad = (F.sources || []).filter(function (r) { return !r.ok; });
    var ok  = (F.sources || []).filter(function (r) { return r.ok; });
    return '<div class="feedbar"><span>Collected <b>' + esc((F.generated || "").slice(0, 10)) +
      "</b></span><span>Window <b>" + esc(F.window_days) + " days</b></span><span>Events <b>" +
      ((F.events || []).length) + "</b></span><span>Feeds <b>" + ok.length + "/" + (F.sources || []).length + "</b></span>" +
      (bad.length ? '<span class="warn">' + bad.map(function (r) { return esc(r.source) + " failed"; }).join(", ") + "</span>" : "") +
      "</div>";
  }

  function qtyTags(e) {
    var q = e.quantities || {}, t = [];
    (q.mw_campus || []).slice(0, 1).forEach(function (v) {
      t.push('<span class="tag qty">' + v.toLocaleString("en-US") + " MW · " + esc(e.mw_basis) + "</span>");
    });
    (q.mw_aggregate || []).slice(0, 1).forEach(function (v) {
      t.push('<span class="tag qty">' + v.toLocaleString("en-US") + " MW aggregate</span>");
    });
    (q.money_musd || []).slice(0, 1).forEach(function (v) {
      t.push('<span class="tag qty">' + (v >= 1000 ? "$" + (v / 1000).toFixed(1) + "B" : "$" + v.toLocaleString("en-US") + "M") + "</span>");
    });
    return t.join("");
  }

  function eventRow(e) {
    var cls = e.event_type.toLowerCase().split("_")[0];
    var parties = (e.neoclouds || []).map(function (n) { return '<span class="tag party neo">' + esc(n) + "</span>"; })
      .concat((e.hyperscalers || []).concat(e.operators || []).map(function (n) { return '<span class="tag party">' + esc(n) + "</span>"; }));
    var flags = [];
    if ((e.commercial_signals || []).indexOf("guarantee") > -1) flags.push('<span class="tag flag">guarantee language</span>');
    if ((e.commercial_signals || []).indexOf("prelease") > -1) flags.push('<span class="tag flag">prelease</span>');
    return '<div class="event" data-type="' + esc(e.event_type) + '" data-neo="' + ((e.neoclouds || []).length ? "1" : "0") + '">' +
      '<div class="event-score' + (e.score >= 12 ? " hot" : "") + '">' + e.score.toFixed(0) + "</div><div>" +
      "<h3><a href=\"" + esc(e.url) + "\" target=\"_blank\" rel=\"noopener\">" + esc(e.title) + "</a></h3>" +
      '<div class="event-meta"><span class="etype ' + esc(cls) + '">' + esc(e.event_type) + "</span>" +
        "<span>" + esc(e.source) + "</span><span>" + esc(e.date) + "</span>" +
        ((e.metros || []).length ? "<span>" + esc(e.metros.join(" / ")) + "</span>" : "") + "</div>" +
      '<div class="tags">' + parties.join("") + qtyTags(e) + flags.join("") +
        (e.power_entities || []).map(function (n) { return '<span class="tag">' + esc(n) + "</span>"; }).join("") +
      "</div></div></div>";
  }

  function emptyState(what) {
    return '<div class="empty"><b>Nothing collected yet</b>' + esc(what) +
      "<br>Run the workflow from the Actions tab, or wait for Monday's scheduled run.</div>";
  }

  function renderActivity() {
    var h = feedBar();
    var events = F && F.events ? F.events : [];

    if (F && F.mw_tally && F.mw_tally.length) {
      var max = Math.max.apply(null, F.mw_tally.map(function (r) { return r.mw; }));
      h += '<h2 class="sec">Announced MW by counterparty</h2><table><caption>' +
        "Sum of the largest campus-scale MW figure per article. Announced, not verified — " +
        "the same campus re-announced counts twice. Treat as a heat map, not a tally.</caption>" +
        "<thead><tr><th>Counterparty</th><th>Kind</th><th class='num'>MW</th><th class='num'>Articles</th><th style='width:30%'></th></tr></thead><tbody>";
      F.mw_tally.forEach(function (r) {
        h += "<tr><td><strong>" + esc(r.name) + "</strong></td><td>" + esc(r.kind) + "</td>" +
          "<td class='num'>" + r.mw.toLocaleString("en-US") + "</td><td class='num'>" + r.events + "</td>" +
          '<td><span class="tbar' + (r.kind === "neocloud" ? " alt" : "") + '" style="width:' +
          (r.mw / max * 100) + '%;margin-top:4px"></span></td></tr>';
      });
      h += "</tbody></table>";
    }

    h += '<h2 class="sec">Event stream</h2>';
    if (!events.length) { h += emptyState("No events in the current window."); }
    else {
      var types = {};
      events.forEach(function (e) { types[e.event_type] = (types[e.event_type] || 0) + 1; });
      h += '<div class="filters" id="filters"><button class="chip" data-f="ALL" aria-pressed="true">All ' + events.length + "</button>" +
        Object.keys(types).sort().map(function (t) {
          return '<button class="chip" data-f="' + esc(t) + '" aria-pressed="false">' + esc(t.replace(/_/g, " ")) + " " + types[t] + "</button>";
        }).join("") + "</div>";
      h += '<div class="events" id="events">' + events.map(eventRow).join("") + "</div>";
    }
    el("panel-activity").innerHTML = h;
    wireFilters();
  }

  function wireFilters() {
    var bar = el("filters"); if (!bar) return;
    bar.addEventListener("click", function (ev) {
      var b = ev.target.closest(".chip"); if (!b) return;
      [].forEach.call(bar.querySelectorAll(".chip"), function (c) {
        c.setAttribute("aria-pressed", c === b ? "true" : "false");
      });
      var f = b.dataset.f;
      [].forEach.call(el("events").children, function (row) {
        row.style.display = (f === "ALL" || row.dataset.type === f) ? "" : "none";
      });
    });
  }

  function renderCredit() {
    var h = '<p class="panel-intro">Neoclouds are the marginal demand behind a large share of announced ' +
      "megawatts, and they are structurally weaker counterparties than the hyperscalers. Their leases are " +
      "the ones where guarantee structure decides whether the credit is real. Tracked separately on purpose.</p>";
    h += feedBar();

    var events = (F && F.events ? F.events : []).filter(function (e) { return (e.neoclouds || []).length; });
    var guar = events.filter(function (e) { return (e.commercial_signals || []).indexOf("guarantee") > -1; });
    var fin  = events.filter(function (e) { return e.event_type === "FINANCING_CLOSED"; });

    h += '<h2 class="sec">What to read for</h2>' +
      '<div class="gapbox"><h3>The clause that decides the credit</h3><ul>' +
      "<li><strong>Parent guarantee</strong> — the operating company's obligation is backed by the group. Underwrite the parent.</li>" +
      "<li><strong>Opco-only</strong> — recourse stops at a thinly capitalised entity. The lease is worth what the SPV is worth.</li>" +
      "<li><strong>Letter of credit</strong> — real but sized; ask for months of rent covered, and who the issuing bank is.</li>" +
      "<li><strong>Hyperscaler backstop</strong> — a neocloud lease with a hyperscaler behind it is a different asset entirely.</li>" +
      "<li><strong>Take-or-pay vs usage</strong> — determines whether GPU demand risk sits with you or the tenant.</li>" +
      "</ul><p>The collector flags articles containing this vocabulary. It cannot tell you which structure applies — that is the judgment pass.</p></div>";

    h += '<h2 class="sec">Flagged: guarantee or credit-support language</h2>';
    h += guar.length ? '<div class="events">' + guar.map(eventRow).join("") + "</div>"
                     : emptyState("No neocloud articles mentioning guarantee structure in this window.");

    h += '<h2 class="sec">Neocloud financing</h2>';
    h += fin.length ? '<div class="events">' + fin.map(eventRow).join("") + "</div>"
                    : emptyState("No neocloud financing events in this window.");

    h += '<h2 class="sec">All neocloud activity</h2>';
    h += events.length ? '<div class="events">' + events.map(eventRow).join("") + "</div>"
                       : emptyState("No neocloud events in this window.");

    el("panel-credit").innerHTML = h;
  }

  /* --- tabs -------------------------------------------------------------- */
  function initTabs() {
    var tabs = [].slice.call(document.querySelectorAll(".tab"));
    function select(id) {
      tabs.forEach(function (t) {
        var on = t.dataset.panel === id;
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.setAttribute("tabindex", on ? "0" : "-1");
        el("panel-" + t.dataset.panel).hidden = !on;
      });
      if (history.replaceState) history.replaceState(null, "", "#" + id);
    }
    tabs.forEach(function (t, i) {
      t.addEventListener("click", function () { select(t.dataset.panel); });
      t.addEventListener("keydown", function (ev) {
        var d = ev.key === "ArrowRight" ? 1 : ev.key === "ArrowLeft" ? -1 : 0;
        if (!d) return;
        ev.preventDefault();
        var next = tabs[(i + d + tabs.length) % tabs.length];
        next.focus(); select(next.dataset.panel);
      });
    });
    var initial = (location.hash || "").replace("#", "");
    select(tabs.some(function (t) { return t.dataset.panel === initial; }) ? initial : "fundamentals");
  }

  /* --- boot -------------------------------------------------------------- */
  el("stamp-built").textContent = D.meta.built;
  el("stamp-scope").textContent = D.meta.scope;
  el("basis").textContent = D.meta.basis;
  renderHero();
  renderFundamentals();
  renderPower();
  renderActivity();
  renderCredit();
  renderCapital();
  renderCounterparty();
  renderEquities();
  initTabs();
})();
